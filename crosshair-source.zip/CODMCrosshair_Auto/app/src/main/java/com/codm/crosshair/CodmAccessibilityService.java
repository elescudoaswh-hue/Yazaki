package com.codm.crosshair;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

public class CodmAccessibilityService extends AccessibilityService {
    private static final String GLOBAL_PACKAGE = "com.activision.callofduty.shooter";
    private static final String GARENA_PACKAGE = "com.garena.game.codm";
    private static final String SYSTEM_UI = "com.android.systemui";

    private WindowManager windowManager;
    private CrosshairView crosshairView;
    private WindowManager.LayoutParams params;
    private boolean showing = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable pendingHide;
    private SharedPreferences prefs;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences("crosshair", MODE_PRIVATE);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;

        String pkg = event.getPackageName().toString();
        if (isCodm(pkg)) {
            cancelPendingHide();
            if (prefs == null) prefs = getSharedPreferences("crosshair", MODE_PRIVATE);
            if (prefs.getBoolean("auto_enabled", true)) {
                showOrUpdate();
            } else {
                hideNow();
            }
            return;
        }

        // Notification shade / volume UI should not make the sight disappear while gaming.
        if (SYSTEM_UI.equals(pkg)) return;

        scheduleHide();
    }

    private boolean isCodm(String pkg) {
        return GLOBAL_PACKAGE.equals(pkg) || GARENA_PACKAGE.equals(pkg);
    }

    private void showOrUpdate() {
        if (windowManager == null) return;
        if (prefs == null) prefs = getSharedPreferences("crosshair", MODE_PRIVATE);

        float scale = prefs.getFloat("scale", 0.60f);
        int xDp = prefs.getInt("x", 0);
        int yDp = prefs.getInt("y", 0);
        float density = getResources().getDisplayMetrics().density;

        int totalSizePx = Math.max(1, Math.round(74f * scale * density));

        if (!showing) {
            crosshairView = new CrosshairView(this);
            crosshairView.setScaleFactor(scale);

            params = new WindowManager.LayoutParams(
                    totalSizePx,
                    totalSizePx,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
            );
            params.gravity = Gravity.CENTER;
            params.x = Math.round(xDp * density);
            params.y = Math.round(yDp * density);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                params.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
            }

            try {
                windowManager.addView(crosshairView, params);
                showing = true;
            } catch (Exception ignored) {
                showing = false;
            }
        } else {
            crosshairView.setScaleFactor(scale);
            params.width = totalSizePx;
            params.height = totalSizePx;
            params.x = Math.round(xDp * density);
            params.y = Math.round(yDp * density);
            try {
                windowManager.updateViewLayout(crosshairView, params);
            } catch (Exception ignored) { }
        }
    }

    private void scheduleHide() {
        cancelPendingHide();
        pendingHide = this::hideNow;
        handler.postDelayed(pendingHide, 450);
    }

    private void cancelPendingHide() {
        if (pendingHide != null) {
            handler.removeCallbacks(pendingHide);
            pendingHide = null;
        }
    }

    private void hideNow() {
        cancelPendingHide();
        if (showing && windowManager != null && crosshairView != null) {
            try {
                windowManager.removeView(crosshairView);
            } catch (Exception ignored) { }
        }
        showing = false;
        crosshairView = null;
        params = null;
    }

    @Override
    public void onInterrupt() {
        hideNow();
    }

    @Override
    public void onDestroy() {
        hideNow();
        super.onDestroy();
    }
}
