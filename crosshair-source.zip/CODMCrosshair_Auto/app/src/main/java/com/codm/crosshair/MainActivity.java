package com.codm.crosshair;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Space;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private TextView status;
    private TextView sizeLabel;
    private TextView xLabel;
    private TextView yLabel;
    private CrosshairView preview;
    private CheckBox autoEnabled;
    private SeekBar sizeSeek;
    private SeekBar xSeek;
    private SeekBar ySeek;

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String value, float sp) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(sp);
        tv.setPadding(0, dp(5), 0, dp(5));
        return tv;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("crosshair", MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(14, 14, 14));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(22), dp(22), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("CODM CROSSHAIR AUTO", 25);
        title.setTextColor(CrosshairView.GREEN);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title);

        status = text("Servicio: comprobando…", 17);
        status.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(status);

        TextView info = text("Aparece automáticamente al entrar a Call of Duty: Mobile y desaparece al salir. Detecta versión Global y Garena.", 15);
        root.addView(info);

        preview = new CrosshairView(this);
        preview.setBackgroundColor(Color.rgb(25, 25, 25));
        preview.setScaleFactor(prefs.getFloat("scale", 0.60f));
        LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(180));
        previewLp.setMargins(0, dp(12), 0, dp(12));
        root.addView(preview, previewLp);

        autoEnabled = new CheckBox(this);
        autoEnabled.setText("Activación automática con COD Mobile");
        autoEnabled.setTextColor(Color.WHITE);
        autoEnabled.setTextSize(16);
        autoEnabled.setChecked(prefs.getBoolean("auto_enabled", true));
        root.addView(autoEnabled);

        float scale = prefs.getFloat("scale", 0.60f);
        sizeLabel = text(String.format(Locale.US, "Tamaño: %.2fx", scale), 16);
        root.addView(sizeLabel);

        sizeSeek = new SeekBar(this);
        sizeSeek.setMax(120); // 0.30 to 1.50
        sizeSeek.setProgress(Math.round((scale - 0.30f) * 100f));
        root.addView(sizeSeek);

        int x = prefs.getInt("x", 0);
        xLabel = text("X: " + x, 16);
        root.addView(xLabel);
        xSeek = new SeekBar(this);
        xSeek.setMax(200);
        xSeek.setProgress(x + 100);
        root.addView(xSeek);

        int y = prefs.getInt("y", 0);
        yLabel = text("Y: " + y, 16);
        root.addView(yLabel);
        ySeek = new SeekBar(this);
        ySeek.setMax(200);
        ySeek.setProgress(y + 100);
        root.addView(ySeek);

        TextView color = text("Color: VERDE  #78C160", 16);
        color.setTextColor(CrosshairView.GREEN);
        root.addView(color);

        Button center = new Button(this);
        center.setText("RESTABLECER 0.60x  •  X:0  •  Y:0");
        root.addView(center);

        Button save = new Button(this);
        save.setText("GUARDAR CONFIGURACIÓN");
        root.addView(save);

        Button access = new Button(this);
        access.setText("ACTIVAR / ABRIR ACCESIBILIDAD");
        root.addView(access);

        TextView privacy = text("Bajo consumo: no hace sondeos ni usa Internet. El servicio solo recibe cambios de ventana de Android; no lee el contenido de la pantalla, no toca controles y no modifica el juego.", 13);
        privacy.setTextColor(Color.LTGRAY);
        root.addView(privacy);

        sizeSeek.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void changed(SeekBar seekBar, int progress) {
                float v = 0.30f + progress / 100f;
                sizeLabel.setText(String.format(Locale.US, "Tamaño: %.2fx", v));
                preview.setScaleFactor(v);
            }
        });
        xSeek.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void changed(SeekBar seekBar, int progress) {
                xLabel.setText("X: " + (progress - 100));
            }
        });
        ySeek.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void changed(SeekBar seekBar, int progress) {
                yLabel.setText("Y: " + (progress - 100));
            }
        });

        center.setOnClickListener(v -> {
            sizeSeek.setProgress(30); // 0.60x
            xSeek.setProgress(100);
            ySeek.setProgress(100);
            autoEnabled.setChecked(true);
            savePrefs();
        });

        save.setOnClickListener(v -> savePrefs());
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        setContentView(scroll);
    }

    private void savePrefs() {
        float scale = 0.30f + sizeSeek.getProgress() / 100f;
        prefs.edit()
                .putBoolean("auto_enabled", autoEnabled.isChecked())
                .putFloat("scale", scale)
                .putInt("x", xSeek.getProgress() - 100)
                .putInt("y", ySeek.getProgress() - 100)
                .apply();
        sizeLabel.setText(String.format(Locale.US, "Tamaño: %.2fx", scale));
        preview.setScaleFactor(scale);
    }

    @Override
    protected void onPause() {
        savePrefs();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void updateStatus() {
        if (isAccessibilityServiceEnabled()) {
            status.setText("Servicio: ACTIVO • listo para COD Mobile");
            status.setTextColor(CrosshairView.GREEN);
        } else {
            status.setText("Servicio: DESACTIVADO • toca ACTIVAR ACCESIBILIDAD");
            status.setTextColor(Color.rgb(255, 190, 80));
        }
    }

    private boolean isAccessibilityServiceEnabled() {
        ComponentName expected = new ComponentName(this, CodmAccessibilityService.class);
        String enabled = Settings.Secure.getString(
                getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        while (splitter.hasNext()) {
            ComponentName component = ComponentName.unflattenFromString(splitter.next());
            if (expected.equals(component)) return true;
        }
        return false;
    }

    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        public abstract void changed(SeekBar seekBar, int progress);
        @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) { changed(seekBar, progress); }
        @Override public void onStartTrackingTouch(SeekBar seekBar) {}
        @Override public void onStopTrackingTouch(SeekBar seekBar) {}
    }
}
