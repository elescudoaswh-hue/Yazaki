package com.codm.crosshair;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

public class CrosshairView extends View {
    public static final int GREEN = Color.rgb(120, 193, 96); // sampled from supplied image

    private final Paint arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float scale = 0.60f;

    public CrosshairView(Context context) {
        super(context);
        init();
    }

    public CrosshairView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        arcPaint.setColor(GREEN);
        arcPaint.setStyle(Paint.Style.STROKE);
        arcPaint.setStrokeCap(Paint.Cap.ROUND);
        dotPaint.setColor(GREEN);
        dotPaint.setStyle(Paint.Style.FILL);
    }

    public void setScaleFactor(float value) {
        scale = Math.max(0.30f, Math.min(1.50f, value));
        invalidate();
    }

    public float getScaleFactor() {
        return scale;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float density = getResources().getDisplayMetrics().density;
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;

        float radius = 27f * density * scale;
        float stroke = 5.4f * density * scale;
        float dotRadius = 4.2f * density * scale;

        arcPaint.setStrokeWidth(stroke);
        RectF oval = new RectF(cx - radius, cy - radius, cx + radius, cy + radius);

        // Four rounded arc segments matching the supplied crosshair.
        float sweep = 52f;
        canvas.drawArc(oval, 334f, sweep, false, arcPaint); // right
        canvas.drawArc(oval, 64f, sweep, false, arcPaint);  // bottom
        canvas.drawArc(oval, 154f, sweep, false, arcPaint); // left
        canvas.drawArc(oval, 244f, sweep, false, arcPaint); // top

        canvas.drawCircle(cx, cy, dotRadius, dotPaint);
    }
}
